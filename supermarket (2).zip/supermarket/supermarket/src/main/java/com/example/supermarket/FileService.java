package com.example.supermarket;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class FileService {
    private final String FILE_PATH = "data.json";
    private final ObjectMapper mapper = new ObjectMapper();
    // 使用 CopyOnWriteArrayList 保证线程安全
    private List<Product> products = new CopyOnWriteArrayList<>();

    public FileService() {
        loadData(); // 启动时加载
    }

    private void loadData() {
        try {
            File file = new File(FILE_PATH);
            if (file.exists()) {
                products = mapper.readValue(file, new TypeReference<List<Product>>() {});
            } else {
                // 初始假数据
                products.add(new Product(1, "Java 8 Coffee", 5.99, 100));
                saveData();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void saveData() {
        try {
            mapper.writeValue(new File(FILE_PATH), products);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Product> getAllProducts() {
        return products;
    }

    public void addProduct(Product product) {
        products.add(product);
        saveData();
    }

    public void deleteProduct(int id) {
        products.removeIf(p -> p.id == id);
        saveData();
    }

    // 【新增】更新商品信息
    public void updateProduct(int id, Product newInfo) {
        for (Product p : products) {
            if (p.id == id) {
                p.name = newInfo.name;
                p.price = newInfo.price;
                p.stock = newInfo.stock;
                saveData(); // 保存更改
                return;
            }
        }
    }
}