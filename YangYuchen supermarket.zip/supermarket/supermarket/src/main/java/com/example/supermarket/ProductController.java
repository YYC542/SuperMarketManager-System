package com.example.supermarket;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin // 允许跨域
public class ProductController {

    private final FileService fileService;

    public ProductController(FileService fileService) {
        this.fileService = fileService;
    }

    // 1. 获取列表
    @GetMapping
    public List<Product> getProducts() {
        return fileService.getAllProducts();
    }

    // 2. 添加商品
    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        fileService.addProduct(product);
        return product;
    }

    // 3. 删除商品
    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable int id) {
        fileService.deleteProduct(id);
    }

    // 4. 【新增】修改商品
    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable int id, @RequestBody Product product) {
        fileService.updateProduct(id, product);
        return product;
    }
}